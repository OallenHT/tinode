// Get these values for your project from the https://console.firebase.google.com/
const FIREBASE_INIT = {
  // Set up a web application in console then get the config object.
  // The following keys are copied from the object:
  apiKey: "AIzaSyD6X4ULR-RUsobvs1zZ2bHdJuPz39q2tbQ",
  messagingSenderId: "114126160546",
  projectId: "tinode-1000",
  appId: "1:114126160546:web:aca6ea2981feb81fb44dfb",
  // Project Settings -> Cloud Messaging -> Web configuration -> Web Push certificates.
  // This value IS NOT included in the generated js config you get from
  // the firebase console. It needs to be added separately.
  messagingVapidKey: "BOgQVPOMzIMXUpsYGpbVkZoEBc0ifKY_f2kSU5DNDGYI6i6CoKqqxDd7w7PJ3FaGRBgVGJffldETumOx831jl58"
};
