// This is a generated file. Don't edit.

export const PACKAGE_VERSION = "0.16.7";
